﻿# Morse Code

This is my take on **Microbit** Morse Code


# How to connect

pin 1 is connected on the sender **Microbit** to pin 2 to receiver **Microbit**
both GRD pins are connected as is

# How it works

**button A** works as a **DOT** and **button B** works as **DASH** for the input
If you shake the **Microbit** it will clear the screen and reset your buffer
If your input does not match with any of the characters from the **Morse Code Look Up Table** The receiver **Microbit** will show **UNKNOWN**

## MORSE CODE LOOK UP TABLE
 ".-": "A",
    "-...": "B",
    "-.-.": "C",
    "-..": "D",
    ".": "E",
    "..-.": "F",
    "--.": "G",
    "....": "H",
    "..": "I",
    ".---": "J",
    "-.-": "K",
    ".-..": "L",
    "--": "M",
    "-.": "N",
    "---": "O",
    ".--.": "P",
    "--.-": "Q",
    ".-.": "R",
    "...": "S",
    "-": "T",
    "..-": "U",
    "...-": "V",
    ".--": "W",
    "-..-": "X",
    "-.--": "Y",
    "--..": "Z",
    ".----": "1",
    "..---": "2",
    "...--": "3",
    "....-": "4",
    ".....": "5",
    "-....": "6",
    "--...": "7",
    "---..": "8",
    "----.": "9",
    "-----": "0"
